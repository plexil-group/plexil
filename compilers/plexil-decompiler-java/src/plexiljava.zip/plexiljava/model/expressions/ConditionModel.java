package plexiljava.model.expressions;

import plexiljava.main.Constants;
import plexiljava.model.BaseModel;
import plexiljava.model.NodeModel;

public class ConditionModel extends NodeModel {
	
	protected String type;
	protected boolean implicit;
	
	public ConditionModel(BaseModel node) {
		this(node, "Generic");
	}
	
	public ConditionModel(BaseModel node, String type) {
		super(node);
		this.type = type;
		
		for( BaseModel child : children ) {
			
		}
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String decompile(int indentLevel) {
		String ret = indent(indentLevel);
		if( hasQuality("NodeRef") ) {
			ret += Constants.DECOMPILE_IDENTIFIER_NODEREF + getQuality("NodeRef").decompile(0);
		} else {
			ret += getType() + " ";
			if( hasQuality("BooleanValue") ) {
				ret += getQuality("BooleanValue").getValue();
			} else if( hasQuality("BooleanVariable") ) {
				ret += getQuality("BooleanVariable").getValue();
			} else if( !children.isEmpty() ){
				ret += children.get(0).decompile(0);
			}
			if( indentLevel != 0 ) {
				ret += ";";
			}
		}
		return ret;
	}

}
