package plexiljava.model.operations;

import plexiljava.model.BaseModel;
import plexiljava.model.expressions.ConditionModel;

public class NOTConditionModel extends ConditionModel {

	public NOTConditionModel(BaseModel node) {
		super(node, "");
	}

	@Override
	public String decompile(int indentLevel) {
		return indent(indentLevel) + "!(" + super.decompile(0) + ")";
	}
	
}
