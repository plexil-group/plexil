package plexiljava.main;

public class Constants {
	
	public static final String INDENT = "  ";
	
	public static final String DECOMPILE_IDENTIFIER_NODEREF = "0NREF0";
	
}
